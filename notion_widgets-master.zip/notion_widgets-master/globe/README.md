# 3D globe

A Pen created on CodePen.io. Original URL: [https://codepen.io/muhammedriyas003/pen/qBBvMrV](https://codepen.io/muhammedriyas003/pen/qBBvMrV).

a simple 3D globe using html and css only