# HTML CSS photo gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/WebSonick/pen/DEpXOZ](https://codepen.io/WebSonick/pen/DEpXOZ).

A beautiful photo gallery with HTML and CSS