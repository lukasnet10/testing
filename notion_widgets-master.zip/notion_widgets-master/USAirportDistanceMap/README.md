# Airport Distance Map

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/vJNMQY](https://codepen.io/shshaw/pen/vJNMQY).

Get the distance between two airports "as the crow flies". 

Built with SVG, Vue, D3, GSAP, and love.

One of the first pieces I made with Vue in 2016, now presented in an updated & cleaned up format.